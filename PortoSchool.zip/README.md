# Portoschool
 A Raspberry Pi3 Project Currently Working in front of a School Entry on a Giant Monitor. Kiosk Display for School news at the School Entry. Shows Pictures and Documents as a Slide and also Current Weather, Daily School Sentries etc.


---
>## Authors
>
  **Kursat Turkay** - Contributor [PortoSchool](https://github.com/kursatturkay/PortoSchool)

---

>#### License

This project is licensed under the Mozilla Public License Version 2.0 - see the [LICENSE.md](./LICENSE.md) file for details

---
>
>## Contributing
>

Please read [CONTRIBUTING.md](https://github.com/kursatturkay/PortoSchool/blob/master/CONTRIBUTING.md) for details on our code of conduct, and the process for submitting pull requests to us.
