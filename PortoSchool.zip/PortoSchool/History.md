﻿### Version: 1.2 
Updated at: 3/24/2018
- XlS Export Support added. Sentinels of Director Assistant Calendar Exporting is now exports as xlsx. no longer csv.

### Version: 1.1 
Updated at: 3/22/2018
- Login Page Removed