﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;

namespace J2i.Net.RealTimeClockSample.ViewModels
{
    public class MainViewModel: ViewModelBase
    {

        RTC_DS3231 _realTimeClock;

        public MainViewModel()
        {
            _realTimeClock = new RTC_DS3231(()=> 
            {
                DateTime? realTime = _realTimeClock.ReadTime();
                DateTimeOffset rtcTime = new DateTimeOffset(_realTimeClock.ReadTime().Value, TimeSpan.Zero);
                CurrentDate = rtcTime.ToLocalTime();
                CurrentTime = rtcTime.ToLocalTime().TimeOfDay;
                SetSystemTime();

                DispatcherTimer timer = new DispatcherTimer();
                timer.Interval = TimeSpan.FromSeconds(1);
                timer.Tick += (oo, ee) =>
                 {
                     ReportedTime = DateTime.Now;
                     SystemDateTime = _realTimeClock.ReadTime().Value; ;

                 };
                timer.Start();
            });
        }

        DateTimeOffset _currentDate;
        public DateTimeOffset CurrentDate
        {
            get { return _currentDate-_currentDate.TimeOfDay;  }
            set
            {
                if(_currentDate != value)
                {
                    _currentDate = value;
                    OnPropertyChanged();
                }
            }
        }


        TimeSpan _currentTime;
        public TimeSpan CurrentTime
        {
            get { return _currentTime;  }
            set
            {
                if(_currentTime != value)
                {
                    _currentTime = value;
                    OnPropertyChanged();
                }
            }
        }


        DateTime _reportedTime;
        public DateTime ReportedTime
        {
            get { return _reportedTime;  }
            set
            {
                if(_reportedTime != value)
                {
                    _reportedTime = value;
                    OnPropertyChanged();
                }
            }
        }

        DateTime _systemDateTime;
        public DateTime SystemDateTime
        {
            get { return _systemDateTime;  }
            set
            {
                if(_systemDateTime != value)
                {
                    _systemDateTime = value;
                    OnPropertyChanged();
                }
            }
        }

        DelegateCommand _setRtcTime;
        public DelegateCommand SetRtcTime
        {
            get
            {
                return _setRtcTime ??
                    (
                    _setRtcTime = new DelegateCommand(() => 
                        {
                            SystemTime sysTime;
                            DateTimeOffset dto = CurrentDate.Date + CurrentTime;
                            var newTime = dto.ToUniversalTime().DateTime;
                            sysTime = new SystemTime(newTime);
                            Win32.SetSystemTime(ref sysTime);
                            _realTimeClock.WriteTime(newTime);
                        
                        })
                    );
            }
        }

        void SetSystemTime()
        {
            var currentTime = CurrentDate + CurrentTime;
            SystemTime sysTime = new SystemTime((currentTime.ToUniversalTime().DateTime));
            Win32.SetSystemTime(ref sysTime);

        }
    }
}
