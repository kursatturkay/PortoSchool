// Copyright (c) Microsoft. All rights reserved.

//
// i2ctesttool
//
//   Utility to read and write I2C devices from the command line.
//   Shows how to use C++/CX in console applications.
//

#include <ppltasks.h>
#include <collection.h>
#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cwctype>
#include <limits>

using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Devices::I2c;
using namespace Windows::Devices;
using namespace Windows::Devices::Enumeration;



using namespace std;

byte BcdToInt(byte bcd)
{
	byte  retVal = (bcd & 0xF) + ((bcd >> 4) * 10);
	return retVal;
}

byte IntToBcd(int v)
{

	byte retVal = (byte)((v % 10) | (v / 10) << 0x4);
	cout << v << " - " << (int) retVal << endl;
	return retVal;
}

void ShowTime(I2cDevice^ realTimeClock)
{
	std::vector<BYTE> readCommand;
	Array<BYTE>^ resultBuffer  = ref new Array<BYTE>(0x7);;
	readCommand.push_back((BYTE)0x00);
	realTimeClock->WriteRead(ArrayReference<BYTE>(readCommand.data(), static_cast<unsigned int>(readCommand.size())), resultBuffer);
	SYSTEMTIME time;
	ZeroMemory(&time, sizeof(time));
	time.wSecond = BcdToInt(resultBuffer[0]);
	time.wMinute = BcdToInt(resultBuffer[1]);
	bool is24HourCock = (resultBuffer[2] >> 0x6) != 1;
	if (is24HourCock)
		time.wHour = (resultBuffer[2] & 0xF) + ((resultBuffer[2] >> 4) & 0x1) * 10 + ((resultBuffer[2] >> 0x5) * 20);
	else
		time.wHour = (resultBuffer[2] & 0xF) + ((resultBuffer[2] >> 4) & 0x1) * 10 + ((resultBuffer[2] >> 0x5) * 12); ;
	time.wDayOfWeek = BcdToInt(resultBuffer[3]);
	time.wDay = BcdToInt(resultBuffer[4]);
	time.wMonth = BcdToInt((byte)(resultBuffer[5] & (byte)0x3f));
	time.wYear = BcdToInt(resultBuffer[6]) + 2000;

	//https://support.microsoft.com/en-us/kb/245786
	FILETIME FileTime, LocalFileTime;
	SYSTEMTIME  LocalTime;
	SystemTimeToFileTime(&time, &FileTime);
	FileTimeToLocalFileTime(&FileTime, &LocalFileTime);
	FileTimeToSystemTime(&LocalFileTime, &LocalTime);

	std::cout << LocalTime.wMonth << "/" << LocalTime.wDay << "/" << LocalTime.wYear 
		<< " " << setfill('0') << setw(2) << LocalTime.wHour << ":" << LocalTime.wMinute << ":" << LocalTime.wSecond;
}

void SetTime(I2cDevice^ realTimeClock)
{
	SYSTEMTIME systemTime;
	GetSystemTime(&systemTime);

	std::vector<BYTE> setTimeCommand;
	setTimeCommand.push_back((BYTE)0x00);
	setTimeCommand.push_back(IntToBcd(systemTime.wSecond));
	setTimeCommand.push_back(IntToBcd(systemTime.wMinute));
	setTimeCommand.push_back(IntToBcd(systemTime.wHour));
	setTimeCommand.push_back(IntToBcd(systemTime.wDayOfWeek));
	setTimeCommand.push_back(IntToBcd(systemTime.wDay));
	setTimeCommand.push_back(IntToBcd(systemTime.wMonth));
	setTimeCommand.push_back(IntToBcd(systemTime.wYear % 100));

	for (int i = 0; i < 10; ++i)
		setTimeCommand.push_back(0);	
	realTimeClock->Write(ArrayReference<BYTE>(setTimeCommand.data(), static_cast<unsigned int>(setTimeCommand.size())));
}

int main (Platform::Array<Platform::String^>^ args)
{
	bool setTime = false;
	if (args->Length > 1)
	{
		setTime = (args->get(1)->Equals(ref new String(L"set-time")));
	}

	String^ aqs = I2cDevice::GetDeviceSelector();
	auto controllerList = concurrency::create_task(DeviceInformation::FindAllAsync(aqs)).get();
	if (controllerList->Size < 1) {
		cout << "no i2c controller found " << endl;
		return -1;
	}
	I2cConnectionSettings^ settings = ref new I2cConnectionSettings(0x68);
	
	settings->BusSpeed = I2cBusSpeed::StandardMode;
	String^ controllerId = controllerList->GetAt(0)->Id;
	auto realTimeClock = concurrency::create_task(I2cDevice::FromIdAsync(controllerId, settings)).get();

	if (setTime) SetTime(realTimeClock);
	else ShowTime(realTimeClock);

    return 0;
}
