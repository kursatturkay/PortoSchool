﻿using RealTimeClock.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace RealTimeClock
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {

        RTC_DS3231 _clock;
        public MainPage()
        {
            this.InitializeComponent();
            _clock = new RTC_DS3231();
            DispatcherTimer timer = new DispatcherTimer() { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += (oo, ee) =>
             {
                 Time.Text =  _clock.ReadTime().Value.ToString();
                 Temperature.Text = _clock.ReadTemperature().ToString();
             };
            timer.Start();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            _clock.WriteTime(DateTime.Now.ToUniversalTime());
            DateTime dt = _clock.ReadTime().Value;
        }
    }
}
